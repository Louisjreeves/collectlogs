$logfolder = "C:\mslog\DTCTrace"
$filename = Get-Date -Format "yyyy-MMdd-HHmmss"
$localMachineName = "localhost"
$tx =  New-DtcDiagnosticTransaction 
Start-Transcript -Path $logfolder\TestMSDTC_$filename.log -Append 

Start-DtcDiagnosticResourceManager -name TestRM17008 -port 17008
Send-DtcDiagnosticTransaction -Transaction $tx -ComputerName $localMachineName -Port 17008
Join-DtcDiagnosticResourceManager -Transaction $tx -ComputerName $localMachineName -Port 17008
Complete-DtcDiagnosticTransaction -Transaction $tx
Stop-DtcDiagnosticResourceManager -name TestRM17008

Stop-Transcript
