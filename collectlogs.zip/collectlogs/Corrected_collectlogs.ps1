﻿
$bull = $false
$script:run = 0
$script:notrun = 0

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[int]$count= 0
[int]$county = 0
$ErrorActionPreference = 'SilentlyContinue'
$WarningPreference =  'SilentlyContinue'

function update-parm {
    Param ([hashtable]$NamedParameters)
    return ($NamedParameters.GetEnumerator() | %{"-$($_.Key) `"$($_.Value)`""}) -join " "
}

function turntopsecond {

# Find cmd.exe processes
$cmdProcesses = Get-Process | Where-Object { $_.ProcessName -eq 'cmd' }
$scriptHostProcesses = Get-Process | Where-Object { $_.ProcessName -match 'cscript|wscript' }

Remove-EtwTraceSession -Name "*$secondselectedvalue*"
Remove-EtwTraceSession -Name "*$selectedvalue*"


if ($cmdProcesses) {
    Write-Host "Command Processor (cmd.exe) processes found:"
    cmdProcesses | Format-Table Id, ProcessName, StartTime -AutoSize

    # Stop cmd.exe processes
  $cmdProcesses | Stop-Process -Force
} else {
    Write-Host "No Command Processor (cmd.exe) processes found."
}

# Find cscript.exe and wscript.exe processes


if ($scriptHostProcesses) {
    Write-Host "Script Host (cscript.exe and wscript.exe) processes found:"
    $scriptHostProcesses | Format-Table Id, ProcessName, StartTime -AutoSize

    Stop script host processes
    $scriptHostProcesses | Stop-Process -Force
} else {
    Write-Host "No Script Host (cscript.exe and wscript.exe) processes found."
}


$runningSessions = Get-WinEvent -ListLog * | Where-Object { $_.IsEnabled -eq $true }

foreach ($session in $runningSessions) {
    $sessionName = $session.LogName
    logman stop $sessionName



}


# Get all active ETW sessions
$activeSessions = logman query -ets | Select-String "Running" | ForEach-Object { $_ -split '\s+' | Select-Object -First 1 }

# Stop each active session
foreach ($session in $activeSessions) {
    logman stop $session
}

$form2.close()

$Form.Close() 



}

Function CLoseall {

$form2.close()
$form2.dispose()
$form.Close()
$form.dispose()


}

 
  function runtrace {
   param (
        [Parameter(Mandatory=$true)][string] $selectedValue,
        [Parameter(Mandatory=$true)][string] $secondSelectedValue
        
    )

  # $thirdselectedValue = "Start"
  
[array]$thirdArray = "START","STOP","REBOOT","DELETE" 

[array]$fourthArray = "1:0:0","0:1:0","0:0:30" ," ", "Custom"

 #$fourthselectedValue = "0:0:30"
   


[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
function senditdown {


 param (
        [Parameter(Mandatory=$true)][string] $selectedValue,
        [Parameter(Mandatory=$true)][string] $secondSelectedValue,
        [Parameter(Mandatory=$true)][string] $thirdselectedvalue,
        [Parameter(Mandatory=$false)][string] $fourthselectedValue
        
    )


 

$script:Choicewpr = $Combo1.SelectedItem.ToString()
$custram = ""

 
set-location -Path $PSScriptRoot
$build1 = ".\shacollector.bat" 

$script:final = " $selectedvalue" + " $secondselectedvalue" + " $thirdselectedvalue" + " $fourthselectedValue"

Write-host ".\shacollector.bat $script:final" -ForegroundColor Green
 $myread= Read-host " The Command which will be deployed is above. Does it look acceptable? "

 if ($myread -notlike 'n') {

 $filePath = Join-Path -Path $PSScriptRoot -ChildPath "output.txt"
 $dotrue = $null

if (Test-Path -Path $filePath) {
    # If the file exists, delete it
    Remove-Item -Path $filePath -Force
}

# Create the file
New-Item -ItemType File -Path $filePath

# Optionally, you can add content to the newly created file, for example:
# "This is a sample content." | Out-File -FilePath $filePath

 
set-location -Path $PSScriptRoot
$script:final = "$selectedValue $secondSelectedValue $thirdSelectedValue $fourthSelectedValue"
#Start-Process .\shacollector.bat -ArgumentList $script:final
#Invoke-Expression -Command ".\shacollector.bat $script:final"
Write-host "Logging is beginning. Run tool again to stop if needed..."

$form.close()
$form.dispose()

$batchOutputFile = "$PSScriptRoot\output.txt"
Start-Process -FilePath "cmd.exe" -ArgumentList "/c .\shacollector.bat $script:final" -Wait
#Invoke-Expression -Command ".\shacollector.bat $script:final >> $batchOutputFile 2>&1"

 
 


# Optionally, you can remove the output file after displaying its contents
#Remove-Item -Path $batchOutputFile
}
Write-host " Start Collect logs GUI to stop the collection using stop and Delete options." -ForegroundColor Green
Write-host " Thank you for using the collect logs tool!" -ForegroundColor Green


 

 
 } else {write-host "exiting"}




function close-DropDown {
$script:Choicewpr = $Combo1.SelectedItem.ToString()

$form2.Close()


}


###BEGIN MSDT WINDOW  
$form2 = New-Object System.Windows.Forms.Form


set-location -Path $PSScriptRoot
$script2run = $PSScriptRoot
 
 
$Image = [system.drawing.image]::FromFile("$($pwd)\Oryx_Antelope.jpg")
$backgroundImage = $Image
$form2.width = 1200
$form2.height = 400
$form2.Text = ”.\shacollector.bat”
## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$form2.AutoSize = $false
$form2.BackgroundImage = $Image
$form2.BackgroundImageLayout = "None"
 # None, Tile, Center, Stretch, Zoom
$form2.Width = $Image.Width
$form2.Height = $Image.Height
$Font = New-Object System.Drawing.Font("Times New Roman",11,[System.Drawing.FontStyle]::Regular)
 # Font styles are: Regular, Bold, Italic, Underline, Strikeout
$form2.TransparencyKey = $backgroundImage.GetPixel(100, 100)
$form2.Font = $Font



$to2lLabel = new-object System.Windows.Forms.Label
$to2lLabel.Location = new-object System.Drawing.Size(520,70)
$to2lLabel.size = new-object System.Drawing.Size(250,20)
$to2lLabel.Text = "Custom Field "
$form2.Controls.Add($to2lLabel)

$to33lLabel = new-object System.Windows.Forms.Label
$to33lLabel.Location = new-object System.Drawing.Size(520,110)
$to33lLabel.size = new-object System.Drawing.Size(250,20)
$to33lLabel.Text = "Common Example Below"
$form2.Controls.Add($to33lLabel)

$IntervalLabel = new-object System.Windows.Forms.Label
$IntervalLabel.Location = new-object System.Drawing.Size(520,130)
$IntervalLabel.size = new-object System.Drawing.Size(250,20)
$IntervalLabel.Text = "Time is 0:0:30 or 0:1:0 or 1:0:0"
$form2.Controls.Add($IntervalLabel)


$Combo1 = new-object System.Windows.Forms.ComboBox
$Combo1.Location = new-object System.Drawing.Size(340,40)
$Combo1.Size = new-object System.Drawing.Size(190,60)

$combo1.Items.AddRange($thirdArray)

ForEach ($Item in $thirdarray) {
[void] $Combo1.Items.Add($Item)
}
 
$Combo1.Add_SelectedIndexChanged({
    $thirdselectedValue = $Combo1.SelectedItem.ToString()
    
})

$form2.Controls.Add($Combo1)

$Combo2 = New-Object System.Windows.Forms.ComboBox
$Combo2.Location = New-Object System.Drawing.Size(540, 40)
$Combo2.Size = New-Object System.Drawing.Size(130, 60)
$Combo2.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList

# Add the array items to the ComboBox
$Combo2.Items.AddRange($fourthArray)

# Handle the SelectedIndexChanged event
$Combo2.Add_SelectedIndexChanged({
    $selectedItem = $Combo2.SelectedItem.ToString()
    if ($selectedItem -eq "Custom") {
        $Combo2.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDown
    } else {
        $Combo2.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    }
})

If ($selecteditem -ne "Custom")
{
ForEach ($Item2 in $fourthArray) { [void]$Combo2.Items.Add($Item2)}
}
 
 $form2.Controls.Add($Combo2)



$DropDownLabel = new-object System.Windows.Forms.Label
$DropDownLabel.Location = new-object System.Drawing.Size(20,40)
$DropDownLabel.size = new-object System.Drawing.Size(100,20)
$DropDownLabel.Text = ".\shacollector.bat"
$form2.Controls.Add($DropDownLabel)

$msgbox1 = New-Object System.Windows.Forms.Label
$msgbox1.Location = New-Object System.Drawing.Size(130, 40)
$msgbox1.Size = New-Object System.Drawing.Size(100, 30)
$Font = New-Object System.Drawing.Font("Times NewRoman", 10, [System.Drawing.FontStyle]::Regular)
$msgbox1.Font = $Font
$msgbox1.Text = "$selectedValue"
#$msgbox1.Add_Click({$form2.Close() })
$form2.Controls.Add($msgbox1)

$msgbox2 = New-Object System.Windows.Forms.Label
$msgbox2.Location = New-Object System.Drawing.Size(230, 40)
$msgbox2.Size = New-Object System.Drawing.Size(100, 30)
$Font = New-Object System.Drawing.Font("Times NewRoman", 10, [System.Drawing.FontStyle]::Regular)
$msgbox2.Font = $Font
$msgbox2.Text = "$SecondselectedValue"
#$msgButton2.Add_Click({ $form2.Close() })
$form2.Controls.Add($msgbox2)

$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(100,90)
$Button.Size = new-object System.Drawing.Size(100,30)
$Button.Text = "Run Job"
 
$Button.Add_Click({

$thirdselectedValue = $Combo1.SelectedItem.ToString()

 #$fourthselectedValue = $Combo2.SelectedItem.ToString()
 $fourthSelectedValue = $Combo2.SelectedItem.ToString()

$form2.Close()
$form2.dispose()

senditdown -selectedValue $selectedValue -secondSelectedValue "$secondSelectedValue" -thirdselectedvalue "$thirdselectedvalue" -fourthselectedValue "$fourthselectedValue"

})

$form2.Controls.Add($Button)

$Button2 = new-object System.Windows.Forms.Button
$Button2.Location = new-object System.Drawing.Size(130,90)
$Button2.Size = new-object System.Drawing.Size(180,30)
$Button2.Text = "Close"
$Button2.Add_Click({close-DropDown})
$form2.Controls.Add($Button2)

 

# Create a RichTextBox control for the instructions
$RichTextBoxInstructions = New-Object System.Windows.Forms.RichTextBox
$RichTextBoxInstructions.Location = New-Object System.Drawing.Point(20, 200)
$RichTextBoxInstructions.Size = New-Object System.Drawing.Size(500, 200)
# Add the instructions text to the RichTextBox control
$RichTextBoxInstructions.Rtf = '{\rtf1\ansi' + $instructions + '}'

$RichTextBoxInstructions.Multiline = $true
$RichTextBoxInstructions.Text = @"
*MUST USE BLANK RIGHT DROPDOWN for basic log. 
*Choose "Custom" and then type D: for other logs
*Custom enables a Typing text box for freehand typing. 
*EMPTY, BLANK or CUSTOM is used for Freedom of Choice 
*Experiment and ITs Ok if it fails. Cleanup and  try again! Examples Below
==========================================================================
SUPPORT: Generates a log and shuts down
TRACE: Start and Stop ETL collection 
PERF: ETL User Created Perfmon Collector
========================================================================== 
Current Trace Collectors: $selectedValue and $secondSelectedValue  
==========================================================================
EXAMPLES:
Support Hyper-V Start D: (Choose the drive letter) CUSTOM
Trace Storport Start BLANK (Select the empty drop down)
Perf Poolmon Start D: (Choose the drive letter) CUSTOM
Perf Memory start tag "POOL TAG FMfn"(CUSTOM type in "POOL TAG FMfn"
perf heap start pid "Process ID 1234" snap
=========================================================================
 .
"@



# Apply bold formatting to "Step 3"
$step3Start = $RichTextBoxInstructions.Text.IndexOf("Step 3")
$RichTextBoxInstructions.Select($step3Start, "Step 3".Length)
$RichTextBoxInstructions.SelectionFont = New-Object System.Drawing.Font($RichTextBoxInstructions.Font, [System.Drawing.FontStyle]::Regular)

 

# Add the RichTextBox control to your form
$Form2.Controls.Add($RichTextBoxInstructions)




$form2.Add_Shown({$form2.Activate()})
[void] $form2.ShowDialog()

 [void] $form2.close()
 


 ## POWER SHELL COMMAND RUN 
 

  }
  


#region Main Form

# Self-elevate the script if required
if (-Not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')) {
    if ([int](Get-CimInstance -Class Win32_OperatingSystem | Select-Object -ExpandProperty BuildNumber) -ge 6000) {
        $CommandLine = "-File `"" + $MyInvocation.MyCommand.Path + "`" " + (update-parm $MyInvocation.BoundParameters) + " " + $MyInvocation.UnboundArguments
        Start-Process -FilePath PowerShell.exe -Verb Runas -ArgumentList $CommandLine
        Exit
    }
}

$menuArray = "TRACE", "PERF", "SUPPORT"

$SupportArray = "ALL", "BASIC", "CLUSTER", "DISK", "DISKSHADOW", "DRIVERINFO", "DRIVE-SPACE", "EVENTLOG", "FLTMC", "FSRM", "HANDLE", "HYPER-V", "ISCSI", "NETWORK", "NFS", "REGISTRY", "STORAGEREPLICA", "SYSTEM", "SYSTEM-NOMSINFO", "TASKSCHEDULER", "VIRTUALFC", "VSS", "SETUP", "FSI", "CRASH", "NOMSINFO"
$performarray = "PERFMON", "CPU", "MEMORY", "DISK", "DELAY", "HEAP"
$tracearray = "STORAGE", "STORPORT", "NTFS", "USB", "PNP", "COM", "VDS", "VSS", "WSB", "CDROM", "ATA", "FSRM", "DEDUP", "NFS", "NETWORK", "ISCSI", "CSV", "WMI", "RPC", "HYPER-V", "CLUSTER", "SPACE", "STORAGEREPLICA", "MSDTC", "FLTMGR", "PACKET", "PROCMON", "PSR", "REFS", "STORSVC", "VHD"

$Form = New-Object System.Windows.Forms.Form
$Form.Width = 782
$Form.Height = 303
$Form.Text = ".\shacollector.bat"



$Image = [system.drawing.image]::FromFile("$($PSScriptRoot)\Oryx_Antelope.jpg")
$backgroundImage = $Image
$form.width = 1200
$form.height = 400
$form.Text = ”.\shacollector.bat”
## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$form.AutoSize = $false
$form.BackgroundImage = $Image
$form.BackgroundImageLayout = "None"
 # None, Tile, Center, Stretch, Zoom
$form.Width = $Image.Width
$form.Height = $Image.Height
$Font = New-Object System.Drawing.Font("Times New Roman",11,[System.Drawing.FontStyle]::Regular)
 # Font styles are: Regular, Bold, Italic, Underline, Strikeout
$form.TransparencyKey = $backgroundImage.GetPixel(100, 100)
$form.Font = $Font

# Create the first dropdown
$DropDown1 = New-Object System.Windows.Forms.ComboBox
$DropDown1.Location = New-Object System.Drawing.Size(150, 39)
$DropDown1.Size = New-Object System.Drawing.Size(133, 19)
$Dropown1.TransparencyKey = $backgroundImage.GetPixel(82, 29)
$DropDown1.BackColor = $backgroundImage.GetPixel(92,39)

# Create the second dropdown
$secondDropDown = New-Object System.Windows.Forms.ComboBox
$secondDropDown.Location = New-Object System.Drawing.Size(150, 79)
$secondDropDown.Size = New-Object System.Drawing.Size(146, 19)
$secondDropDown.TransparencyKey = $backgroundImage.GetPixel(83, 89)
$secondDropDown.BackColor = $backgroundImage.GetPixel(83,89)

$DropDown1.Items.AddRange($menuArray)

# Add event handler to first dropdown
$DropDown1.Add_SelectedIndexChanged({
    $selectedValue = $DropDown1.SelectedItem.ToString()
    $secondDropDown.Items.Clear()

    switch ($selectedValue) {
        'Trace' {
            $secondDropDown.Items.AddRange($tracearray)
        }
        'Perf' {
            $secondDropDown.Items.AddRange($performarray)
        }
        'Support' {
            $secondDropDown.Items.AddRange($SupportArray)
        }
    }
    $secondDropDown.Enabled = $true
})

$Form.Controls.Add($DropDown1)
$Form.Controls.Add($secondDropDown)

$DropDownLabel = New-Object System.Windows.Forms.Label
$DropDownLabel.Location = New-Object System.Drawing.Size(1, 39)
$DropDownLabel.Size = New-Object System.Drawing.Size(115, 20)
$DropDownLabel.TransparencyKey = $backgroundImage.GetPixel(20,30)
$DropDownLabel.BackColor = $backgroundImage.GetPixel(20,30)
$DropDownLabel.Text = "Log Type"
$Form.Controls.Add($DropDownLabel)

$secondLabel = New-Object System.Windows.Forms.Label
$secondLabel.Location = New-Object System.Drawing.Size(1, 80)
$secondLabel.Size = New-Object System.Drawing.Size(150, 20) 

$SecondLabel.TransparencyKey = $backgroundImage.GetPixel(82, 89)
$SecondLabel.BackColor = $backgroundImage.GetPixel(82, 89)
$secondLabel.Text = "Type of Collection"
$Form.Controls.Add($secondLabel)
 

$Button = New-Object System.Windows.Forms.Button
$Button.Location = New-Object System.Drawing.Size(310, 29)
$Button.Size = New-Object System.Drawing.Size(240, 29)
$Button.Text = "Choose Collection Type"
$Button.Add_Click({
    # Handle the button click event
    $selectedValue = $DropDown1.SelectedItem.ToString()
    $secondSelectedValue = $secondDropDown.SelectedItem.ToString()

    Write-Host "First Dropdown Selected: $selectedValue"
    Write-Host "Second Dropdown Selected: $secondSelectedValue"

    Runtrace $selectedValue $secondSelectedValue

})
$Form.Controls.Add($Button)

$secondButton = New-Object System.Windows.Forms.Button
$secondButton.Location = New-Object System.Drawing.Size(600, 43)
#235 151
$secondButton.Size = New-Object System.Drawing.Size(160, 30)
$secondButton.Text = "Kill All Processes"
$secondButton.Add_Click({ Turntopsecond })
$Form.Controls.Add($secondButton)



$thirdButton = New-Object System.Windows.Forms.Button
$thirdButton.Location = New-Object System.Drawing.Size(600, 5)

$thirdButton.Size = New-Object System.Drawing.Size(160, 25)
$thirdButton.Text = "Save and Exit"
$thirdButton.Add_Click({ closeall })
$Form.Controls.Add($thirdButton)





$DropDownLabel2 = New-Object System.Windows.Forms.Label
$DropDownLabel2.Location = New-Object System.Drawing.Size(1, 10)
$DropDownLabel2.Size = New-Object System.Drawing.Size(125, 20)
$DropDownLabel2.TransparencyKey = $backgroundImage.GetPixel(20, 15)
$DropDownLabel2.BackColor = $backgroundImage.GetPixel(21,15)
$Font = New-Object System.Drawing.Font("Times NewRoman", 11, [System.Drawing.FontStyle]::Bold)
$DropDownLabel2.font = $font
$DropDownLabel2.Text = "Run choices"
$Form.Controls.Add($DropDownLabel2)
#########################################

$CloseButton = New-Object System.Windows.Forms.Label
$CloseButton.Location = New-Object System.Drawing.Size(50, 180)
$CloseButton.Size = New-Object System.Drawing.Size(700, 30)
$Font = New-Object System.Drawing.Font("Times NewRoman", 14, [System.Drawing.FontStyle]::Bold)
$CloseButton.Font = $Font
$CloseButton.TransparencyKey = $backgroundImage.GetPixel(200, 300)
$CloseButton.BackColor = $backgroundImage.GetPixel(200,200)
$CloseButton.Text = "Logs located at c:\MsLab"
$CloseButton.Add_Click({ $Form.Close() })
$Form.Controls.Add($CloseButton)

$gasButton = New-Object System.Windows.Forms.Label
$gasButton.Location = New-Object System.Drawing.Size(50, 210)
$gasButton.Size = New-Object System.Drawing.Size(700, 30)
$Font = New-Object System.Drawing.Font("Times NewRoman", 14, [System.Drawing.FontStyle]::Regular)
$gasButton.Font = $Font
$gasButton.TransparencyKey = $backgroundImage.GetPixel(200, 300)
$gasButton.BackColor = $backgroundImage.GetPixel(200,200)
$gasButton.Text = "and in Script Root"
$gasButton.Add_Click({ $Form.Close() })
$Form.Controls.Add($gasButton)


 $StatusButton = New-Object System.Windows.Forms.Button
$StatusButton.Location = New-Object System.Drawing.Size(50, 340)
#235 151
$StatusButton.Size = New-Object System.Drawing.Size(160, 30)
$StatusButton.Text = "Check Again"
$StatusButton.Add_Click({
    $script:run++  # Increment the counter on button click
    Write-host $script:run
    # Perform the process checking
    $cmdProcesses = Get-Process | Where-Object { $_.ProcessName -eq 'cmd' }
    $scriptHostProcesses = Get-Process | Where-Object { $_.ProcessName -match 'cscript|wscript' }

    $yeswehavetrace = Get-EtwTraceSession -Name "*$secondselectedvalue*"
    $2wehaveatrave = Get-EtwTraceSession -Name  "*$selectedvalue*"
   $auto=  Get-AutologgerConfig -Name "*$secondselectedvalue*"

    If ($yeswehavetrace -or $2wehaveatrave -or $auto){
    
     $msgButton.Text = "Running Log Detected in -Check# $script:run"

# Create a RichTextBox control for the instructions
$RichTextBoxrunning = New-Object System.Windows.Forms.RichTextBox
$RichTextBoxrunning.Location = New-Object System.Drawing.Point(20, 400)
$RichTextBoxrunning.Size = New-Object System.Drawing.Size(400, 200)
# Add the instructions text to the RichTextBox control
$RichTextBoxrunning.Rtf = '{\rtf1\ansi' + $instructions + '}'

$RichTextBoxrunning.Multiline = $true
   $activeSessions =  logman query -ets
   $RichTextBoxrunning.Text = $activeSessions

# Apply bold formatting to "Step 3"
$step3Start = $RichTextBoxInstructions.Text.IndexOf("Step 3")
$RichTextBoxrunning.Select($step3Start, "Step 3".Length)
$RichTextBoxrunning.SelectionFont = New-Object System.Drawing.Font($RichTextBoxrunning.Font, [System.Drawing.FontStyle]::Bold)
# Add the RichTextBox control to your form
$Form.Controls.Add($RichTextBoxrunning)
    
    }Elseif ($cmdProcesses -or $scriptHostProcesses) {
        $msgButton.Text = "Running Log Detected in $script:run Tries"
    } else {
        $msgButton.Text = "No Running Log Now -Check# $script:run"
    }

})
$Form.Controls.Add($StatusButton)





$msgButton = New-Object System.Windows.Forms.Label
$msgButton.Location = New-Object System.Drawing.Size(50, 310)
$msgButton.Size = New-Object System.Drawing.Size(360, 30)
$Font = New-Object System.Drawing.Font("Times NewRoman", 12, [System.Drawing.FontStyle]::Bold)
$msgButton.Font = $Font
$msgButton.TransparencyKey = $backgroundImage.GetPixel(200, 300)
$msgButton.BackColor = $backgroundImage.GetPixel(200,200)
$msgButton.Text = "Collection will self Delete But Check here"
$msgButton.Add_Click({ $Form.Close() })
$Form.Controls.Add($msgButton)


$Form.Add_Shown({ $Form.Activate() })
[void] $Form.ShowDialog()

#endregion Main Form
